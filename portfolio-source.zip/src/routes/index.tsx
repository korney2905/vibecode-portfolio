import { createFileRoute } from "@tanstack/react-router";
import { FeaturedProjects } from "@/components/featured-projects";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Избранные проекты — Вайбкодинг-портфолио" },
    { name: "description", content: "StudyFlow, НейроАналитик и LaunchPro — избранные AI- и веб-проекты специалиста по вайбкодингу." },
    { property: "og:title", content: "Избранные проекты — Вайбкодинг-портфолио" },
    { property: "og:description", content: "Три идеи, ставшие цифровыми продуктами: обучение, аналитика и запуск продукта." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

function Index() {
  return <main><FeaturedProjects /></main>;
}
