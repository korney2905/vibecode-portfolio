import { BookOpen, ChartNoAxesCombined, Layers, Sparkles } from "lucide-react";
import brickWall from "@/assets/brick-wall.jpg";

const projects = [
  { name: "StudyFlow", category: "AI · ОБРАЗОВАНИЕ", description: "AI-платформа для персонализированного обучения. Подбирает программу под ваши цели, темп и уровень знаний.", technologies: ["React", "TypeScript", "OpenAI", "Supabase"], theme: "study", number: "01" },
  { name: "НейроАналитик", category: "AI · АНАЛИТИКА", description: "AI-сервис для анализа данных. Превращает сложные таблицы в понятные выводы и наглядные отчёты.", technologies: ["Python", "React", "OpenAI", "Pandas"], theme: "analytics", number: "02" },
  { name: "LaunchPro", category: "WEB · ЛЕНДИНГ", description: "Лендинг для запуска продукта. Выразительный дизайн, чёткая структура и фокус на конверсии.", technologies: ["React", "TypeScript", "Tailwind CSS", "Framer Motion"], theme: "launch", number: "03" },
] as const;

function ProjectPreview({ theme }: { theme: typeof projects[number]["theme"] }) {
  return <div className={`project-preview preview-${theme}`} aria-label={`Концепт интерфейса ${theme === "study" ? "StudyFlow" : theme === "analytics" ? "НейроАналитик" : "LaunchPro"}`} role="img">
    <div className="preview-browser"><span /><span /><span /><div className="preview-address">{theme === "study" ? "studyflow.app" : theme === "analytics" ? "neuroanalytics.ai" : "launchpro.site"}</div></div>
    {theme === "study" ? <div className="study-ui"><aside><BookOpen size={17}/><i/><i/><i/><i/></aside><div className="study-content"><div className="mini-brand">StudyFlow <Sparkles size={10}/></div><strong>Твой следующий шаг</strong><div className="study-course"><div className="course-symbol"><Layers size={25}/></div><div><b>Основы UX-дизайна</b><p>Модуль 3 · Визуальная иерархия</p><div className="progress-track"><span/></div></div></div><div className="mini-tiles"><div><b>12</b><span>уроков пройдено</span></div><div><b>85%</b><span>твой прогресс</span></div></div></div></div>
    : theme === "analytics" ? <div className="analytics-ui"><div className="mini-brand"><ChartNoAxesCombined size={13}/> НейроАналитик <span>Обзор</span></div><div className="analytics-stats"><div><span>Выручка</span><b>₽ 842 500</b></div><div><span>Рост за месяц</span><b>+24,8%</b></div><div><span>Конверсия</span><b>8,4%</b></div></div><div className="chart-header">Динамика показателей <span>Последние 7 месяцев</span></div><div className="bar-chart">{[32, 48, 42, 66, 58, 79, 94].map((height, index) => <div key={height} className={`chart-bar bar-${index}`}><span/><small>{["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл"][index]}</small></div>)}</div></div>
    : <div className="launch-ui"><div className="mini-brand">launchpro<span>Продукт　 Возможности　 ↗</span></div><div className="launch-orbit"><Layers size={34}/></div><div className="launch-pill">ТВОЯ ИДЕЯ. НОВЫЙ УРОВЕНЬ.</div><strong>Большие идеи.<br/>Яркий запуск.</strong><p>Всё, что нужно для следующего шага.</p><div className="launch-cta">Начать сейчас <span>↗</span></div></div>}
  </div>;
}

export function FeaturedProjects() {
  return <section className="featured-section" aria-labelledby="featured-title">
    <img className="brick-background" src={brickWall} alt="" width={1536} height={1024}/>
    <div className="featured-inner">
      <header className="featured-header"><div className="section-eyebrow"><span/> ОТ ИДЕИ ДО ПРОДУКТА</div><h1 id="featured-title">Избранные <span>проекты</span><span className="heading-period">.</span></h1><p>Идеи, которые стали работающими цифровыми продуктами.</p></header>
      <div className="project-grid">{projects.map(project => <article key={project.name} className={`project-card card-${project.theme}`}><ProjectPreview theme={project.theme}/><div className="project-details"><div className="project-category">{project.category}<span>{project.number}</span></div><h2>{project.name}</h2><p>{project.description}</p><ul className="technology-tags" aria-label="Технологии">{project.technologies.map(technology => <li key={technology}>{technology}</li>)}</ul></div></article>)}</div>
      <div className="section-end"><span>СОЗДАНО С КОДОМ. УСИЛЕНО AI.</span><span>03 ПРОЕКТА</span></div>
    </div>
  </section>;
}